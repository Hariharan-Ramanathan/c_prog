struct dll_node {
 int data;
 dll_node *next;
 dll_node *prev;
};

dll_node* dll_new_node(int data)  { 
 dll_node* temp = malloc(sizeof(dll_node));
 temp->data = data;
 temp->prev = NULL;
 temp->next = NULL;
 return temp;
}

void dll_print(dll_node* head)  { 
 dll_node* p = head;
 while(p!=NULL)  {
  printf("%d  ",p->data);
  p = p->next;
  }
  printf("\n");
}
   
void dll_push_at_end(dll_node** head, dll_node** tail, int data)  { 
   dll_node* new_node = dll_new_node(data);
    
   if((*head) == NULL)  {
    (*head) = new_node;
    (*tail) = (*head);
   } 
   else if((*head)->next == NULL)	{
     new_node->prev = *head;
    (*head)->next = new_node;
    (*tail) = new_node;
   }
   else {
   	new_node->prev = *tail;
   	(*tail)->next = new_node;
   	(*tail) = (*tail)->next;
   }	 
}

void dll_push_at_start(dll_node** head, dll_node** tail, int data)  {
   if((*head) == NULL)  {
    (*head) = dll_new_node(data);
    (*tail) = (*head);
	} 
   else  {
    dll_node* p = dll_new_node(data);
    p->next = (*head);
    (*head) = p;
    }
}
int dll_pop_at_end(dll_node** head, dll_node** tail)  {
	int res = 0;
	if(*head == NULL) {
	}
	else if(*head == *tail)	{
		res = (*head)->data;
		(*head) = NULL;
		(*tail) = NULL;
	}
	else if((*head)->next == (*tail))  {
		res = (*tail)->data;
		(*head)->next = NULL;	
		(*tail) = (*tail)->prev;
		(*tail)->next = NULL;
	}
	else	{
		res = (*tail)->data;
		(*tail) = (*tail)->prev;
		(*tail)->next = NULL;
		
	}
	return res;
}	
	
int dll_pop_at_start(dll_node** head, dll_node** tail)	{
	int res = 0;
	if((*head) == NULL)	{
	}	
	else if(*head == *tail)	{
		res = (*head)->data;
		(*head) = NULL;
		(*tail) = NULL;
	}
	else  {
		res = (*head)->data;
		(*head) = (*head)->next;
		(*head)->prev = NULL;
	}	
	return res;	 		
}				

