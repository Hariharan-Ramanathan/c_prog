#include<stdio.h>
#include "swapit.h"
#include "head.h"
#include "main.c"

