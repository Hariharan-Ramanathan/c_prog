struct adjlist{
	struct sll_node* head;
};

struct graph{
	int vertices;
	struct adjlist* array;
};

struct sll_node* graph_new_adj_list(int data){
	struct sll_node* newnode=(struct sll_node*)malloc(sizeof(struct sll_node));
	newnode->data=data;
	newnode->next=NULL;
	return newnode;
}

struct graph* create_graph(int ip){
	struct graph* new_graph=(struct graph*)malloc(sizeof(struct graph));
	new_graph->vertices=ip;
	new_graph->array=(struct adjlist*)malloc(ip*sizeof(struct adjlist));
	for(int i=0;i<ip;i++){
		new_graph->array[i].head=NULL;
	}
	return new_graph;
}

/*void graph_add_egde(struct graph* ip,int src,int sec){
	struct sll_node* newnode=graph_new_adj_list(sec);
	newnode->next=ip->array[src].head;
	ip->array[src].head=newnode;
	
	newnode=graph_new_adj_list(src);
	newnode->next=ip->array[sec].head;
	ip->array[sec].head=newnode;
}*/

void graph_add_edge(struct graph* ip, int src, int sec) 
{ 
	struct sll_node* newnode = graph_new_adj_list(sec); 
	newnode->next = ip->array[src].head; 
	ip->array[src].head = newnode; 
	
	newnode = graph_new_adj_list(src); 
	newnode->next = ip->array[sec].head; 
	ip->array[sec].head = newnode; 
}

void graph_print_graph(struct graph* ip_graph){
	for(int i=0;i<ip_graph->vertices;i++){
		struct sll_node* temp=ip_graph->array[i].head;
		printf("\nAdjency list of vertices %d \n head ",i);
		while(temp!=NULL){
			printf("->%d",temp->data);
			temp=temp->next;
		}
		printf("\n");
		
	}
}
